import os
import shutil
import uuid

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.schemas import ScanResponse
from app.settings import UPLOADS_DIR, OUTPUTS_DIR
from app.inference.scan_user_apk import scan_user_apk

app = FastAPI(title="Android Malware FSL API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

app.mount("/outputs", StaticFiles(directory=OUTPUTS_DIR), name="outputs")


@app.get("/")
def root():
    return {"message": "Android Malware FSL backend is running"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/scan", response_model=ScanResponse)
async def scan(apk: UploadFile = File(...)):
    if not apk.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")

    unique_name = f"{uuid.uuid4()}_{apk.filename}"
    apk_path = os.path.join(UPLOADS_DIR, unique_name)

    try:
        with open(apk_path, "wb") as f:
            shutil.copyfileobj(apk.file, f)

        result = scan_user_apk(apk_path)
        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))